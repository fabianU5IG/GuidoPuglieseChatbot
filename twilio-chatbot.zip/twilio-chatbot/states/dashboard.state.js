import timeUtils from "../utils/time.js";
import {
    getPendingCases,
    markCancelled,
    markReScheduled,
    registerChatbotInteraction,
    logAppointmentMessage,
} from "../services/chatbot-db.service.js";
import { createSaludtoolsJob } from "../services/saludtools-jobs.service.js";

const { getTimeSlots } = timeUtils;

/**
 * =========================
 *  CONFIG
 * =========================
 */
const SECRETARY_PHONES = ["573224811542"];
const SECRETARY_CASES_PAGE_SIZE = 10;

const APPOINTMENT_DURATION_MIN = Number(
    process.env.SALUDTOOLS_APPOINTMENT_DURATION_MIN || 30,
);

const DOCTOR_DOCUMENT_TYPE = Number(
    process.env.SALUDTOOLS_DOCTOR_DOCUMENT_TYPE || 1,
);
const DOCTOR_DOCUMENT_NUMBER = String(
    process.env.SALUDTOOLS_DOCTOR_DOCUMENT_NUMBER || "99988877711",
);
const CLINIC_ID = Number(process.env.SALUDTOOLS_CLINIC_ID || 8);

const APPOINTMENT_MODALITY =
    process.env.SALUDTOOLS_APPOINTMENT_MODALITY || "CONVENTIONAL";
const APPOINTMENT_STATE = process.env.SALUDTOOLS_APPOINTMENT_STATE || "PENDING";

function splitName(fullName = "") {
    const parts = String(fullName).trim().split(/\s+/).filter(Boolean);
    if (parts.length === 0) return { firstName: "", secondName: "", firstLastName: "", secondLastName: "" };
    if (parts.length === 1) return { firstName: parts[0], secondName: "", firstLastName: "", secondLastName: "" };
    if (parts.length === 2) return { firstName: parts[0], secondName: "", firstLastName: parts[1], secondLastName: "" };
    if (parts.length === 3) return { firstName: parts[0], secondName: parts[1], firstLastName: parts[2], secondLastName: "" };
    return {
        firstName: parts[0],
        secondName: parts.slice(1, parts.length - 2).join(" "),
        firstLastName: parts[parts.length - 2],
        secondLastName: parts[parts.length - 1],
    };
}

const DASHBOARD_MENU_TEXT = "👋 Panel de Secretaría\n\n1️⃣ Crear cita rápida\n2️⃣ Ver casos pendientes\n\n0️⃣ Salir";

function capitalizeWords(str = "") {
    return String(str)
        .trim()
        .split(/\s+/)
        .filter(Boolean)
        .map(
            (word) =>
                word.charAt(0).toUpperCase() + word.slice(1).toLowerCase(),
        )
        .join(" ");
}

function buildFullNameFromParts(item = {}) {
    const parts = [
        item.firstName,
        item.secondName,
        item.firstLastName,
        item.secondLastName,
        item.first_name,
        item.second_name,
        item.first_last_name,
        item.second_last_name,
    ]
        .map((v) => String(v || "").trim())
        .filter(Boolean);

    return capitalizeWords(parts.join(" "));
}

function extractPatientName(item = {}) {
    const directCandidates = [
        item.fullName,
        item.patientFullName,
        item.patientName,
        item.name,
        item.full_name,
        item.patient_full_name,
        item.patient_name,
    ]
        .map((v) => String(v || "").trim())
        .filter(Boolean);

    if (directCandidates.length) {
        return capitalizeWords(directCandidates[0]);
    }

    const built = buildFullNameFromParts(item);
    if (built) return built;

    const nestedBuilt = buildFullNameFromParts(item.patient || {});
    if (nestedBuilt) return nestedBuilt;

    const nestedCandidates = [
        item.patient?.fullName,
        item.patient?.patientFullName,
        item.patient?.patientName,
        item.patient?.name,
        item.patient?.full_name,
        item.patient?.patient_full_name,
        item.patient?.patient_name,
    ]
        .map((v) => String(v || "").trim())
        .filter(Boolean);

    if (nestedCandidates.length) {
        return capitalizeWords(nestedCandidates[0]);
    }

    return "";
}

function extractPatientDocument(item = {}) {
    const candidates = [
        item.documentNumber,
        item.patientDocumentNumber,
        item.identification,
        item.cc,
        item.document_number,
        item.patient_document_number,
        item.patient?.documentNumber,
        item.patient?.patientDocumentNumber,
        item.patient?.identification,
        item.patient?.cc,
        item.patient?.document_number,
        item.patient?.patient_document_number,
    ]
        .map((v) => String(v || "").trim())
        .filter(Boolean);

    return candidates.length ? candidates[0] : "";
}

function buildPatientDisplay(item = {}) {
    const name = extractPatientName(item);
    const document = extractPatientDocument(item);

    if (name && document) return `${name} - CC ${document}`;
    if (name) return name;
    if (document) return `CC ${document}`;

    return "Paciente sin identificar";
}

function addMinutesToYmdHm(ymd, hm, minutesToAdd) {
    const [H, M] = hm.split(":").map(Number);
    const [Y, Mo, D] = ymd.split("-").map(Number);

    const dt = new Date(Y, Mo - 1, D, H, M, 0, 0);
    dt.setMinutes(dt.getMinutes() + minutesToAdd);

    const yyyy = String(dt.getFullYear()).padStart(4, "0");
    const mm = String(dt.getMonth() + 1).padStart(2, "0");
    const dd = String(dt.getDate()).padStart(2, "0");
    const hh = String(dt.getHours()).padStart(2, "0");
    const min = String(dt.getMinutes()).padStart(2, "0");

    return { ymd: `${yyyy}-${mm}-${dd}`, hm: `${hh}:${min}` };
}

function ddmmToYmd(ddmm) {
    const [day, month] = ddmm.split("/").map(Number);
    const year = new Date().getFullYear();
    const d = new Date(year, month - 1, day);
    const yyyy = String(d.getFullYear()).padStart(4, "0");
    const mm = String(d.getMonth() + 1).padStart(2, "0");
    const dd = String(d.getDate()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
}

function isValidDateDDMM(value) {
    if (!/^\d{2}\/\d{2}$/.test(value)) return false;

    const [day, month] = value.split("/").map(Number);
    const year = new Date().getFullYear();

    const date = new Date(year, month - 1, day);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    return !isNaN(date) && date >= today;
}

function paginateCases(
    cases = [],
    page = 0,
    pageSize = SECRETARY_CASES_PAGE_SIZE,
) {
    const safePage = Math.max(0, Number(page || 0));
    const start = safePage * pageSize;
    const end = start + pageSize;

    return {
        items: cases.slice(start, end),
        page: safePage,
        pageSize,
        total: cases.length,
        hasNext: end < cases.length,
        hasPrev: safePage > 0,
        totalPages: Math.ceil(cases.length / pageSize),
        start,
        end,
    };
}

function toEmojiNumber(value) {
    const map = {
        0: "0️⃣",
        1: "1️⃣",
        2: "2️⃣",
        3: "3️⃣",
        4: "4️⃣",
        5: "5️⃣",
        6: "6️⃣",
        7: "7️⃣",
        8: "8️⃣",
        9: "9️⃣",
    };

    return String(value)
        .split("")
        .map((char) => map[char] || char)
        .join("");
}

function formatCaseLine(c, absoluteIndex) {
    const when =
        c.date || c.time
            ? `🗓️ ${c.date || "Sin fecha"} ${c.time || ""}`.trim()
            : "🗓️ Sin fecha";

    const emojiIndex = toEmojiNumber(absoluteIndex + 1);

    return (
        `${emojiIndex} ${buildPatientDisplay(c)}\n` +
        `${when}\n` +
        `Estado Saludtools: ${c.status || "N/A"}\n` +
        `${c.internal_status ? `Estado local: ${c.internal_status}\n` : ""}\n`
    );
}

function dashboardHeader() {
    return "📋 Dashboard Secretaría\n\n";
}

function buildPendingCasesResponse(cases = [], page = 0, extra = "") {
    const paginated = paginateCases(cases, page);

    if (!paginated.items.length) {
        return {
            response:
                (extra ? `${extra}\n\n` : "") +
                dashboardHeader() +
                "No hay casos pendientes.\n\n0️⃣ Salir",
            nextState: "DASHBOARD",
            data: { step: "INBOX", page: 0, cases: [] },
        };
    }

    let response = extra
        ? `${extra}\n\n📋 Casos pendientes (${paginated.total} en total):\n\n`
        : `📋 Casos pendientes (${paginated.total} en total):\n\n`;

    paginated.items.forEach((c, i) => {
        response += formatCaseLine(c, paginated.start + i);
    });

    response += `Página ${paginated.page + 1} de ${Math.max(
        1,
        paginated.totalPages,
    )}\n`;

    if (paginated.hasNext) {
        response += "\n1️⃣1️⃣ Ver más casos";
    }

    if (paginated.hasPrev) {
        response += "\n1️⃣2️⃣ Ver casos anteriores";
    }

    response +=
        "\n\nSelecciona un caso por su número global o escribe 0️⃣ para salir";

    return {
        response,
        nextState: "DASHBOARD",
        data: { step: "SELECT_CASE", cases, page: paginated.page },
    };
}

async function returnToInbox(extra = "", page = 0) {
    let cases = [];
    try {
        cases = await getPendingCases();
    } catch (err) {
        console.error("❌ Error getPendingCases:", err);
        cases = [];
    }

    if (!Array.isArray(cases)) cases = [];

    return buildPendingCasesResponse(cases, page, extra);
}

async function cancelSelectedCase({ from, data }) {
    const apptId = data?.selectedCase?.appointment_id || null;
    const saludId = data?.selectedCase?.saludtools_appointment_id || null;
    const patientDocType = Number(
        data?.selectedCase?.patient_document_type || 1,
    );
    const patientDocNumber = String(
        data?.selectedCase?.patient_document_number ||
        data?.selectedCase?.document_number ||
        extractPatientDocument(data?.selectedCase || {}) ||
        "",
    ).trim();

    try {
        if (apptId) {
            await markCancelled(apptId, { changedBy: "SECRETARY" });

            await registerChatbotInteraction({
                phone: from,
                appointmentId: apptId,
                appointmentData: { newStatus: "CANCELLED" },
            });

            await logAppointmentMessage(
                apptId,
                "Secretaría: marcó CANCELLED desde dashboard",
            );
        }
    } catch (err) {
        console.error("❌ Error cancelando en DB:", err);
    }

    let workerMsg = "Worker: omitido";
    try {
        if (!data?.skipSaludtools && saludId) {
            await createSaludtoolsJob({
                jobType: "APPOINTMENT_DELETE",
                phone: from,
                appointmentId: apptId || null,
                dedupeKey: `dashboard-appointment-delete:${saludId}`,
                payload: {
                    appointmentId: saludId,
                    internalAppointmentId: apptId || null,
                    documento: patientDocNumber,
                    patientDocumentType: patientDocType,
                    source: "SECRETARY_DASHBOARD",
                },
                priority: 90,
            });

            workerMsg = "Worker: solicitud de cancelación encolada ✅";

            if (apptId) {
                await logAppointmentMessage(
                    apptId,
                    "Solicitud de cancelación encolada para worker desde dashboard",
                );
            }
        } else if (!saludId) {
            workerMsg = "Worker: omitido (sin ID de Saludtools)";
        } else if (data?.skipSaludtools) {
            workerMsg = "Worker: omitido (decisión de secretaría)";
        }
    } catch (err) {
        workerMsg = "Worker: error encolando ⚠️";
        if (apptId) {
            await logAppointmentMessage(
                apptId,
                `Error encolando cancelación para worker: ${String(
                    err?.message || err,
                ).slice(0, 800)}`,
            );
        }
    }

    return {
        response:
            "❌ Cita marcada como *CANCELADA*\n\n" +
            `${workerMsg}\n\n` +
            `${apptId ? "" : "Nota: no se encontró cita local enlazada; solo se aseguró la sincronización con Saludtools.\n\n"}` +
            "1️⃣ Terminar\n" +
            "2️⃣ Volver al dashboard",
        nextState: "DASHBOARD",
        data: { step: "AFTER_ACTION" },
    };
}

export default async function dashboardState(msg, data = {}, context) {
    const from = (context?.from || "").replace(/\D/g, "");

    if (!SECRETARY_PHONES.includes(from)) {
        return {
            response: "❌ Acceso no autorizado.",
            nextState: "MENU",
            data: {},
        };
    }

    if (!data.step) {
        data.step = "MENU";
        return {
            response: DASHBOARD_MENU_TEXT,
            nextState: "DASHBOARD",
            data,
        };
    }

    switch (data.step) {
        case "MENU": {
            if (msg === "0") {
                return {
                    response: "👋 Saliendo del dashboard",
                    nextState: "MENU",
                    data: { renderMenu: true },
                };
            }
            if (msg === "1") {
                data.step = "QUICK_NAME";
                return {
                    response: "📝 *Creación rápida de cita*\n\nEscribe el nombre completo del paciente:",
                    nextState: "DASHBOARD",
                    data,
                };
            }
            if (msg === "2") {
                data.step = "INBOX";
                let cases = [];
                try {
                    cases = await getPendingCases();
                } catch (err) {
                    console.error("❌ Error getPendingCases:", err);
                }
                return buildPendingCasesResponse(cases || [], 0);
            }
            return { response: DASHBOARD_MENU_TEXT, nextState: "DASHBOARD", data };
        }

        case "QUICK_NAME": {
            if (msg === "0") {
                data.step = "MENU";
                return { response: DASHBOARD_MENU_TEXT, nextState: "DASHBOARD", data };
            }
            data.quickName = msg.trim();
            data.step = "QUICK_DOC_TYPE";
            return {
                response: "Tipo de documento:\n\n1️⃣ CC\n2️⃣ CE\n\n0️⃣ Volver",
                nextState: "DASHBOARD",
                data,
            };
        }

        case "QUICK_DOC_TYPE": {
            if (msg === "0") {
                data.step = "MENU";
                return { response: DASHBOARD_MENU_TEXT, nextState: "DASHBOARD", data };
            }
            if (msg !== "1" && msg !== "2") {
                return { response: "Selecciona 1️⃣ o 2️⃣", nextState: "DASHBOARD", data };
            }
            data.quickDocType = Number(msg);
            data.step = "QUICK_DOC_NUM";
            return { response: "Número de documento:", nextState: "DASHBOARD", data };
        }

        case "QUICK_DOC_NUM": {
            if (msg === "0") {
                data.step = "MENU";
                return { response: DASHBOARD_MENU_TEXT, nextState: "DASHBOARD", data };
            }
            const doc = msg.replace(/\D/g, "");
            if (doc.length < 5) {
                return { response: "Número inválido. Intenta de nuevo:", nextState: "DASHBOARD", data };
            }
            data.quickDocNum = doc;
            data.step = "QUICK_PHONE";
            return { response: "Número de WhatsApp del paciente (ej: 573001234567):", nextState: "DASHBOARD", data };
        }

        case "QUICK_PHONE": {
            if (msg === "0") {
                data.step = "MENU";
                return { response: DASHBOARD_MENU_TEXT, nextState: "DASHBOARD", data };
            }
            const ph = msg.replace(/\D/g, "");
            if (ph.length < 7) {
                return { response: "Teléfono inválido. Intenta de nuevo:", nextState: "DASHBOARD", data };
            }
            data.quickPhone = ph;
            data.step = "QUICK_DATE";
            return { response: "Fecha de la cita (DD/MM):", nextState: "DASHBOARD", data };
        }

        case "QUICK_DATE": {
            if (msg === "0") {
                data.step = "MENU";
                return { response: DASHBOARD_MENU_TEXT, nextState: "DASHBOARD", data };
            }
            if (!isValidDateDDMM(msg)) {
                return { response: "Fecha inválida (DD/MM). Intenta de nuevo:", nextState: "DASHBOARD", data };
            }
            data.quickDate = msg;
            data.page = 0;
            data.step = "QUICK_TIME";
            return buildTimeResponseForDashboard(data);
        }

        case "QUICK_TIME": {
            if (msg === "0") {
                data.step = "MENU";
                return { response: DASHBOARD_MENU_TEXT, nextState: "DASHBOARD", data };
            }
            if (msg === "7") {
                data.page++;
                return buildTimeResponseForDashboard(data);
            }
            const index = parseInt(msg, 10) - 1;
            const slots = getTimeSlots(data.page);
            const hour = slots[index];
            if (!hour) return { response: "Opción inválida.", nextState: "DASHBOARD", data };

            data.quickTime = hour;
            data.step = "QUICK_CONFIRM";
            return {
                response: `📝 *Confirmar Cita Rápida*\n\n` +
                    `Paciente: ${data.quickName}\n` +
                    `Documento: ${data.quickDocType === 1 ? 'CC' : 'CE'} ${data.quickDocNum}\n` +
                    `WhatsApp: ${data.quickPhone}\n` +
                    `Fecha: ${data.quickDate}\n` +
                    `Hora: ${data.quickTime}\n\n` +
                    `1️⃣ Confirmar y agendar\n` +
                    `0️⃣ Cancelar y volver`,
                nextState: "DASHBOARD",
                data,
            };
        }

        case "QUICK_CONFIRM": {
            if (msg === "0") {
                data.step = "MENU";
                return { response: DASHBOARD_MENU_TEXT, nextState: "DASHBOARD", data };
            }
            if (msg !== "1") {
                return { response: "Responde 1️⃣ para confirmar o 0️⃣ para volver.", nextState: "DASHBOARD", data };
            }

            const ymd = ddmmToYmd(data.quickDate);
            const end = addMinutesToYmdHm(ymd, data.quickTime, APPOINTMENT_DURATION_MIN);
            const nameParts = splitName(data.quickName);

            await createSaludtoolsJob({
                jobType: "APPOINTMENT_CREATE",
                phone: data.quickPhone,
                dedupeKey: `quick-create:${data.quickDocNum}:${ymd}:${data.quickTime}`,
                payload: {
                    fullName: data.quickName,
                    dateLabel: data.quickDate,
                    timeLabel: data.quickTime,
                    patientExistsLocal: false,
                    patientBody: {
                        ...nameParts,
                        birthDate: "1900-01-01",
                        gender: 1,
                        documentType: data.quickDocType,
                        documentNumber: data.quickDocNum,
                        phone: data.quickPhone,
                        cellPhone: data.quickPhone,
                        email: "",
                        eps: 0,
                        habeasData: true,
                    },
                    appointmentBody: {
                        startAppointment: `${ymd} ${data.quickTime}`,
                        endAppointment: `${end.ymd} ${end.hm}`,
                        patientDocumentType: data.quickDocType,
                        patientDocumentNumber: data.quickDocNum,
                        doctorDocumentType: DOCTOR_DOCUMENT_TYPE,
                        doctorDocumentNumber: DOCTOR_DOCUMENT_NUMBER,
                        modality: APPOINTMENT_MODALITY,
                        stateAppointment: APPOINTMENT_STATE,
                        appointmentType: "Consulta (Agendada por Secretaría)",
                        clinic: CLINIC_ID,
                        comment: `Creada por secretaría desde dashboard.`,
                    },
                },
                priority: 110,
            });

            return {
                response: "✅ Solicitud de creación enviada al sistema.\n\n1️⃣ Terminar\n2️⃣ Volver al panel",
                nextState: "DASHBOARD",
                data: { step: "AFTER_ACTION" },
            };
        }

        case "INBOX": {
            let cases = [];
            try {
                cases = await getPendingCases();
            } catch (err) {
                console.error("❌ Error getPendingCases:", err);
                cases = [];
            }

            if (!Array.isArray(cases)) cases = [];

            return buildPendingCasesResponse(cases, 0);
        }

        case "SELECT_CASE": {
            if (msg === "0") {
                return {
                    response: "👋 Saliendo del dashboard",
                    nextState: "MENU",
                    data: {},
                };
            }

            const allCases = Array.isArray(data.cases) ? data.cases : [];
            const currentPage = Number(data.page || 0);
            const paginated = paginateCases(allCases, currentPage);
            const raw = String(msg || "").trim();

            if (raw === "11") {
                if (!paginated.hasNext) {
                    return buildPendingCasesResponse(
                        allCases,
                        currentPage,
                        "⚠️ No hay más casos para mostrar.",
                    );
                }

                return buildPendingCasesResponse(allCases, currentPage + 1);
            }

            if (raw === "12") {
                if (!paginated.hasPrev) {
                    return buildPendingCasesResponse(
                        allCases,
                        currentPage,
                        "⚠️ Ya estás en la primera página.",
                    );
                }

                return buildPendingCasesResponse(allCases, currentPage - 1);
            }

            const requestedNumber = parseInt(raw, 10);
            const index = Number.isInteger(requestedNumber)
                ? requestedNumber - 1
                : -1;

            if (!Number.isInteger(index) || !allCases[index]) {
                return buildPendingCasesResponse(
                    allCases,
                    currentPage,
                    "❌ Opción inválida",
                );
            }

            const selectedCase = allCases[index];

            const details =
                `🔔 Caso seleccionado\n\n` +
                `Paciente: ${buildPatientDisplay(selectedCase)}\n` +
                `Documento: ${extractPatientDocument(selectedCase) || "N/A"}\n` +
                `Cita: ${selectedCase.date || "Sin fecha"} ${selectedCase.time || ""}\n` +
                `Estado Saludtools: ${selectedCase.status || "N/A"}\n` +
                `Estado local: ${selectedCase.internal_status || "N/A"}\n` +
                `Appointment ID local: ${selectedCase.appointment_id || "N/A"}\n` +
                `Saludtools ID: ${selectedCase.saludtools_appointment_id || "N/A"}\n\n` +
                "1️⃣ Reagendar\n" +
                "2️⃣ Cancelar\n" +
                "0️⃣ Volver";

            return {
                response: details,
                nextState: "DASHBOARD",
                data: {
                    step: "CASE_ACTIONS",
                    selectedCase,
                    cases: allCases,
                    page: currentPage,
                },
            };
        }

        case "CASE_ACTIONS": {
            if (msg === "0") {
                return returnToInbox(
                    "↩️ Volviendo al listado",
                    Number(data.page || 0),
                );
            }

            if (msg === "1") {
                const saludId = data?.selectedCase?.saludtools_appointment_id;
                if (!saludId) {
                    return {
                        response:
                            "⚠️ Este caso no tiene *Saludtools ID*.\n\n" +
                            "Escribe el ID de Saludtools para reagendar, o escribe 0️⃣ para continuar sin actualizar en Saludtools:",
                        nextState: "DASHBOARD",
                        data: {
                            ...data,
                            step: "ASK_SALUD_ID",
                            pendingAction: "RESCHEDULE",
                        },
                    };
                }

                return {
                    response:
                        "🔄 Reagendar cita\n\nIngresa la nueva fecha (DD/MM):",
                    nextState: "DASHBOARD",
                    data: {
                        ...data,
                        step: "ASK_DATE",
                        pendingAction: "RESCHEDULE",
                        skipSaludtools: false,
                    },
                };
            }

            if (msg === "2") {
                const saludId = data?.selectedCase?.saludtools_appointment_id;
                if (!saludId) {
                    return {
                        response:
                            "⚠️ Este caso no tiene *Saludtools ID*.\n\n" +
                            "Escribe el ID de Saludtools para cancelar también en Saludtools, o escribe 0️⃣ para cancelar solo en el sistema interno:",
                        nextState: "DASHBOARD",
                        data: {
                            ...data,
                            step: "ASK_SALUD_ID",
                            pendingAction: "CANCEL",
                        },
                    };
                }

                return await cancelSelectedCase({
                    from,
                    data: { ...data, skipSaludtools: false },
                });
            }

            return {
                response: "❌ Opción inválida",
                nextState: "DASHBOARD",
                data,
            };
        }

        case "ASK_SALUD_ID": {
            const raw = String(msg || "").trim();

            if (raw === "0") {
                const next =
                    data?.pendingAction === "CANCEL" ? "DO_CANCEL" : "ASK_DATE";
                return {
                    response:
                        data?.pendingAction === "CANCEL"
                            ? "✅ Cancelando en el sistema interno... (Saludtools omitido)"
                            : "✅ Continuemos con la reprogramación... (Saludtools omitido)",
                    nextState: "DASHBOARD",
                    data: { ...data, step: next, skipSaludtools: true },
                };
            }

            const id = raw.replace(/\D/g, "");
            if (!id) {
                return {
                    response:
                        "❌ ID inválido. Escribe solo números, o 0️⃣ para omitir Saludtools:",
                    nextState: "DASHBOARD",
                    data,
                };
            }

            data.selectedCase = {
                ...(data.selectedCase || {}),
                saludtools_appointment_id: id,
            };

            const next =
                data?.pendingAction === "CANCEL" ? "DO_CANCEL" : "ASK_DATE";
            return {
                response:
                    data?.pendingAction === "CANCEL"
                        ? "✅ Cancelando en el sistema interno y Saludtools..."
                        : "✅ Continuemos con la reprogramación...",
                nextState: "DASHBOARD",
                data: { ...data, step: next, skipSaludtools: false },
            };
        }

        case "DO_CANCEL": {
            return await cancelSelectedCase({ from, data });
        }

        case "ASK_DATE": {
            if (msg === "0") {
                return returnToInbox(
                    "↩️ Volviendo al listado",
                    Number(data.page || 0),
                );
            }

            if (!isValidDateDDMM(msg)) {
                return {
                    response:
                        "❌ Fecha inválida.\nDebe ser DD/MM y futura.\n\nIntenta de nuevo:",
                    nextState: "DASHBOARD",
                    data,
                };
            }

            data.newDate = msg;
            data.page = 0;
            data.step = "ASK_TIME";
            return buildTimeResponseForDashboard(data);
        }

        case "ASK_TIME": {
            if (msg === "0") {
                return returnToInbox(
                    "↩️ Volviendo al listado",
                    Number(data.page || 0),
                );
            }

            if (msg === "7") {
                data.page++;
                return buildTimeResponseForDashboard(data);
            }

            const index = parseInt(msg, 10) - 1;
            const slots = getTimeSlots(data.page);
            const hour = slots[index];

            if (!hour) {
                return {
                    response:
                        "❌ Opción inválida. Elige un número del listado.",
                    nextState: "DASHBOARD",
                    data,
                };
            }

            data.newTime = hour;
            data.step = "CONFIRM_RESCHEDULE";

            const sel = data.selectedCase || {};
            return {
                response:
                    "✅ Confirma la reprogramación:\n\n" +
                    `Paciente: ${buildPatientDisplay(sel)}\n` +
                    `Tel: ${sel.phone || "N/A"}\n` +
                    `Nueva cita: ${data.newDate} ${data.newTime}\n\n` +
                    "1️⃣ Confirmar\n" +
                    "0️⃣ Cancelar",
                nextState: "DASHBOARD",
                data,
            };
        }

        case "CONFIRM_RESCHEDULE": {
            if (msg === "0") {
                return returnToInbox(
                    "↩️ Acción cancelada. Volviendo al listado.",
                    Number(data.page || 0),
                );
            }

            if (msg !== "1") {
                return {
                    response: "Responde 1️⃣ para confirmar o 0️⃣ para cancelar.",
                    nextState: "DASHBOARD",
                    data,
                };
            }

            const apptId = data?.selectedCase?.appointment_id || null;
            const saludId =
                data?.selectedCase?.saludtools_appointment_id || null;
            const patientDocType = Number(
                data?.selectedCase?.patient_document_type || 1,
            );
            const patientDocNumber = String(
                data?.selectedCase?.patient_document_number ||
                data?.selectedCase?.document_number ||
                extractPatientDocument(data?.selectedCase || {}) ||
                "",
            ).trim();

            try {
                if (apptId) {
                    await markReScheduled(apptId, {
                        newDate: data.newDate,
                        newTime: data.newTime,
                        changedBy: "SECRETARY",
                    });

                    await registerChatbotInteraction({
                        phone: from,
                        appointmentId: apptId,
                        appointmentData: {
                            newStatus: "RESCHEDULED",
                            newDate: data.newDate,
                            newTime: data.newTime,
                        },
                    });

                    await logAppointmentMessage(
                        apptId,
                        `Secretaría: reagendó a ${data.newDate} ${data.newTime} desde dashboard`,
                    );
                }
            } catch (err) {
                console.error("❌ Error reagendando en DB:", err);
            }

            let workerMsg = "Worker: omitido";
            try {
                if (!data?.skipSaludtools && saludId) {
                    const ymd = ddmmToYmd(data.newDate);
                    const end = addMinutesToYmdHm(
                        ymd,
                        data.newTime,
                        APPOINTMENT_DURATION_MIN,
                    );

                    await createSaludtoolsJob({
                        jobType: "APPOINTMENT_UPDATE",
                        phone: from,
                        appointmentId: apptId || null,
                        dedupeKey: `dashboard-appointment-update:${saludId}:${ymd}:${data.newTime}`,
                        payload: {
                            appointmentId: saludId,
                            internalAppointmentId: apptId || null,
                            documento: patientDocNumber,
                            patientDocumentType: patientDocType,
                            appointmentBody: {
                                id: String(saludId),
                                startAppointment: `${ymd} ${data.newTime}`,
                                endAppointment: `${end.ymd} ${end.hm}`,
                                patientDocumentType: patientDocType,
                                patientDocumentNumber: patientDocNumber,
                                doctorDocumentType: DOCTOR_DOCUMENT_TYPE,
                                doctorDocumentNumber: DOCTOR_DOCUMENT_NUMBER,
                                modality: APPOINTMENT_MODALITY,
                                stateAppointment: APPOINTMENT_STATE,
                                notificationState: "ATTEND",
                                appointmentType:
                                    data?.selectedCase?.attention_type ||
                                    "Cita (reprogramada por secretaría)",
                                clinic: CLINIC_ID,
                                comment: `Reprogramada por secretaría. Paciente: ${extractPatientName(
                                    data?.selectedCase || {},
                                )}`,
                            },
                            source: "SECRETARY_DASHBOARD",
                        },
                        priority: 90,
                    });

                    workerMsg =
                        "Worker: solicitud de reagendamiento encolada ✅";

                    if (apptId) {
                        await logAppointmentMessage(
                            apptId,
                            `Solicitud de reagendamiento encolada para worker: ${ymd} ${data.newTime}`,
                        );
                    }
                } else if (!saludId) {
                    workerMsg = "Worker: omitido (sin ID de Saludtools)";
                } else if (data?.skipSaludtools) {
                    workerMsg = "Worker: omitido (decisión de secretaría)";
                }
            } catch (err) {
                workerMsg = "Worker: error encolando ⚠️";
                if (apptId) {
                    await logAppointmentMessage(
                        apptId,
                        `Error encolando reagendamiento para worker: ${String(
                            err?.message || err,
                        ).slice(0, 800)}`,
                    );
                }
            }

            return {
                response:
                    "🔄 Cita marcada como *REAGENDADA*\n\n" +
                    `Nueva fecha/hora: ${data.newDate} ${data.newTime}\n\n` +
                    `${workerMsg}\n\n` +
                    `${apptId ? "" : "Nota: no se encontró cita local enlazada; se priorizó la actualización en Saludtools.\n\n"}` +
                    "1️⃣ Terminar\n" +
                    "2️⃣ Volver al dashboard",
                nextState: "DASHBOARD",
                data: { step: "AFTER_ACTION" },
            };
        }

        case "AFTER_ACTION": {
            if (msg === "1") {
                return {
                    response: "✅ Proceso finalizado",
                    nextState: "END",
                    data: {},
                };
            }

            if (msg === "2") {
                return {
                    response: "📋 Volviendo al dashboard...\n",
                    nextState: "DASHBOARD",
                    data: { step: "INBOX" },
                };
            }

            return {
                response: "Selecciona 1️⃣ o 2️⃣",
                nextState: "DASHBOARD",
                data,
            };
        }

        default:
            return {
                response: "⚠️ Reiniciando dashboard...",
                nextState: "DASHBOARD",
                data: { step: "INBOX" },
            };
    }
}

function buildTimeResponseForDashboard(data) {
    const slots = getTimeSlots(data.page);
    let response = "Horas disponibles:\n\n";

    slots.forEach((h, i) => {
        response += `${i + 1}️⃣ ${h}\n`;
    });

    if (getTimeSlots(data.page + 1).length) {
        response += "\n7️⃣ Más horarios";
    }

    response += "\n\n0️⃣ Volver al listado";

    return { response, nextState: "DASHBOARD", data };
}
